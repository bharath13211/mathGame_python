from models.OperationMap import operationMap
from models import Question
from models.QuestionRepository import QuestionRepository
from models.QuestionWrapper import QuestionWrapper

class mathGame:
    questionRepository = QuestionRepository()
    operationMap = operationMap()
    isGameCompleted = False
    def __init__(self,operationmap):
        self.operationMap = operationmap

    def chooseOperation(self):
        print("Enter operation key you want to perform ")
        self.operationMap.printAvailableOperations()
        operationId = input()
        options = [1,2,3,4]

        print("Please solve below equations")
        self.questionRepository = self.operationMap.getQuestionRepository(operationId)

    def chooseReply(self):
        print("Wanna play game again? yes/no")
        feedback = input()
        if feedback == 'no':
            self.isGameCompleted = True

    def start(self):
        total = 0
        if self.isGameCompleted:
            print("Game Over")
        else:
            self.chooseOperation()
            questionList = self.questionRepository.getQuestion(10)
            #taskList = []

            for i in range(len(questionList)):
                wrapper = QuestionWrapper(i, questionList[i])
                wrapper.collectAnswer()
                #taskList.append(wrapper)
                if wrapper.printFeedback():
                    total+=1
            print("You have answered ",total,"correct out of 10")
            print("Your percentage is ",total*10)

            #for i in taskList:


            self.chooseReply()
            self.start()





