from models.Question import question

class QuestionWrapper():
    questionNumber:int
    question: question
    answerProvided = ''
    #scanner = input()

    def __init__(self,questionNumber,question):
        self.questionNumber = questionNumber
        self.question = question

    def collectAnswer(self):
        print(self.questionNumber+1,") ", self.question.getequation(),"=")
        self.answerProvided = input()
    def printFeedback(self):
        st = self.question.validate(self.answerProvided)
        print("Status: ",self.getStatus(st))
        if not st:
        #print(st)
            print("Correct Answer:", self.question.getanswer())
            print("Provided Answer:", self.answerProvided)
            print("")
        return st
    def getStatus(self,isCorrect):
        if(isCorrect):
            return "Corect"
        else:
            return "Wrong"
