
class question():
    equation = ''
    answer = 0
    def __init__(self,equation,answer):
        self.equation = equation
        self.answer = answer
    def validate(self,ans):
        self.isCorrect = False
        try:
            int(ans)
            if int(ans) == self.answer:
                self.isCorrect = True
            return self.isCorrect
        except:
            print("You have entered Wrong characters")
            return self.isCorrect

    def getequation(self):
        return self.equation
    def getanswer(self):
        return self.answer

