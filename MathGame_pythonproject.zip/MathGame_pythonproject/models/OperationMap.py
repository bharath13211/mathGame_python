from repositories.SubQuestionRepository import SubQuestionRepository
from repositories.AddQuestionRepository import AddQuestionRepository
from repositories.DivQuestionRepository import DivQuestionRepository
from repositories.MulQuestionRepository import MulQuestionRepository

class operationMap:
    opeationDescription = {}
    questionRepositoryMap = {}
    def __init__(self):
        self.opeationDescription[1] = "Addition"
        self.opeationDescription[2] = "Subtraction"
        self.opeationDescription[3] = "Multiplication"
        self.opeationDescription[4] = "Division"

        self.questionRepositoryMap[1] = AddQuestionRepository()
        self.questionRepositoryMap[2] = SubQuestionRepository()
        self.questionRepositoryMap[3] = MulQuestionRepository()
        self.questionRepositoryMap[4] = DivQuestionRepository()

    def printAvailableOperations(self):
        print(self.opeationDescription)
    def getQuestionRepository(self,operationId):

        return self.questionRepositoryMap[int(operationId)]




