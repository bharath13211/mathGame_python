
class QuestionRepository:
    def getQuestion(self,numQuestions):
        pass