from models.Question import question
#from models import QuestionRepository

class MulQuestionRepository():#QuestionRepository):
    questionList = []
    def __init__(self):
        self.questionList.append(question("1*2", 2))
        self.questionList.append(question("2*5", 10))
        self.questionList.append(question("10*15", 150))
        self.questionList.append(question("2*51", 102))
        self.questionList.append(question("13*8", 104))
        self.questionList.append(question("6*3", 18))
        self.questionList.append(question("10*100", 1000))
        self.questionList.append(question("24*3", 72))
        self.questionList.append(question("1*1", 1))
        self.questionList.append(question("12*12", 144))

    def getQuestion(self,numQuestions):
        n = len(self.questionList)
        q_list = []
        for i in range(numQuestions):
            q_list.append(self.questionList[i%n])
        return q_list

