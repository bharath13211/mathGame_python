from models.Question import question
from models.QuestionRepository import QuestionRepository

class AddQuestionRepository(QuestionRepository):
    questionList = []
    def __init__(self):
        self.questionList.append(question("1+2",3))
        self.questionList.append(question("2+5", 7))
        self.questionList.append(question("12+15", 27))
        self.questionList.append(question("21+51", 72))
        self.questionList.append(question("13+8", 21))
        self.questionList.append(question("6+3", 9))
        self.questionList.append(question("10+100", 110))
        self.questionList.append(question("24+23", 47))
        self.questionList.append(question("1+1", 2))
        self.questionList.append(question("101+109", 210))

    def getQuestion(self,numQuestions):
        n = len(self.questionList)
        q_list = []
        for i in range(numQuestions):
            q_list.append(self.questionList[i % n])
        return q_list

