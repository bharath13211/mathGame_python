from models.Question import question
#from models import QuestionRepository

class SubQuestionRepository():#QuestionRepository):
    questionList = []
    def __init__(self):
        self.questionList.append(question("2-1", 1))
        self.questionList.append(question("5-2", 3))
        self.questionList.append(question("15-12", 3))
        self.questionList.append(question("21-5", 16))
        self.questionList.append(question("13-8", 5))
        self.questionList.append(question("6-3", 3))
        self.questionList.append(question("100-10", 90))
        self.questionList.append(question("24-23", 1))
        self.questionList.append(question("1-1", 0))
        self.questionList.append(question("111-10", 101))

    def getQuestion(self,numQuestions):
        n = len(self.questionList)
        q_list = []
        for i in range(numQuestions):
            q_list.append(self.questionList[i%n])
        return q_list

