from models.Question import question
#from models import QuestionRepository

class DivQuestionRepository():#QuestionRepository):
    questionList = []
    def __init__(self):
        self.questionList.append(question("10/2", 5))
        self.questionList.append(question("4/4", 1))
        self.questionList.append(question("16/4", 4))
        self.questionList.append(question("20/10", 2))
        self.questionList.append(question("52/26", 2))
        self.questionList.append(question("100/4", 25))
        self.questionList.append(question("30/15", 2))
        self.questionList.append(question("10/5", 2))
        self.questionList.append(question("21/3", 7))
        self.questionList.append(question("105/5", 21))

    def getQuestion(self,numQuestions):
        n = len(self.questionList)
        q_list = []
        for i in range(numQuestions):
            q_list.append(self.questionList[i%n])
        return q_list

